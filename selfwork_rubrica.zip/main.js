//bottoni

let btnShow = document.querySelector('#mostra_contatti');
let btnAdd = document.querySelector('#btnAgg');
let btnRem = document.querySelector('#btn_Rmv');

//input dati

let nameInpt = document.querySelector('#nomeCtn');
let numbInpt = document.querySelector('#numCtn');

//scheda contatto

let cardCtn = document.querySelector('#scheda_contatto');

//variabile di appoggio
let check = false;

//Contatti in Rubrica

const lista = {
  lista_rubrica : [
  {nome_contatto: 'Fabio Dannico', numero_contatto: 343567897},
  {nome_contatto: 'Alberto Felici', numero_contatto: 342675456},
  {nome_contatto: 'Michela Cianciotti', numero_contatto: 361789654},
  ],
  
  mostraCnct : function(){
    cardCtn.innerHTML='';
    this.lista_rubrica.forEach((contatto)=>{
      let div = document.createElement('div');
      div.innerHTML = `<p> ${contatto.nome_contatto} </p>
                       <p>${contatto.numero_contatto}</p>`;
                       
    cardCtn.appendChild(div);
    })
  }
  
  
};

btnShow.addEventListener('click', ()=>{
  if (check == false){
    lista.mostraCnct();
    check = true;
    btnShow.innerHTML = 'Nascondi Contatti';
  }else{
    cardCtn.innerHTML = '';
    check = false;
    btnShow.innerHTML = 'Mostra Contatti';
    
  }
});


